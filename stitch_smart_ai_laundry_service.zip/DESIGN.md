---
name: Purity Tech
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#464652'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#777683'
  outline-variant: '#c7c5d4'
  surface-tint: '#4f54b4'
  primary: '#15157d'
  on-primary: '#ffffff'
  primary-container: '#2e3192'
  on-primary-container: '#9da1ff'
  inverse-primary: '#c0c1ff'
  secondary: '#6d4ca6'
  on-secondary: '#ffffff'
  secondary-container: '#c09cfd'
  on-secondary-container: '#4f2e87'
  tertiary: '#002b43'
  on-tertiary: '#ffffff'
  tertiary-container: '#004264'
  on-tertiary-container: '#60b1ea'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e1e0ff'
  primary-fixed-dim: '#c0c1ff'
  on-primary-fixed: '#04006d'
  on-primary-fixed-variant: '#373a9b'
  secondary-fixed: '#ebdcff'
  secondary-fixed-dim: '#d4bbff'
  on-secondary-fixed: '#270058'
  on-secondary-fixed-variant: '#55338d'
  tertiary-fixed: '#cbe6ff'
  tertiary-fixed-dim: '#8ecdff'
  on-tertiary-fixed: '#001e30'
  on-tertiary-fixed-variant: '#004b71'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  headline-xl:
    fontFamily: Montserrat
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Montserrat
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Montserrat
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-md:
    fontFamily: Montserrat
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  section-gap-desktop: 80px
  section-gap-mobile: 40px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
---

## Brand & Style
The design system is anchored in the concept of "Effortless Purity." It bridges the gap between high-precision artificial intelligence and the soft, tactile comfort of freshly laundered linens. The target audience is urban professionals and tech-savvy households who value time and hygiene.

The visual style is **Corporate / Modern** with a strong leaning toward **Minimalism**. It utilizes expansive white space to evoke a sense of "clean air" and "sterility," while softening the technical edges with gentle gradients and rounded geometry. The emotional response should be one of immediate relief, reliability, and modern sophistication.

## Colors
The palette is designed to simulate the spectrum of water and fabric care. 
- **Deep Indigo** serves as the anchor, providing a foundation of trust and professional authority.
- **Soft Lavender** is used for accents and secondary actions, representing garment care and luxury.
- **Sky Blue and Mint Green** are functional colors, used to denote freshness, ecological safety, and "clean" status updates.
- **Backgrounds** utilize a "Cool White" strategy, using very high-luminance grey-blues to prevent eye strain while maintaining a bright, airy environment.

## Typography
The typographic system pairs the geometric confidence of Montserrat for headings with the high-performance legibility of Inter for UI and body text. 

Headlines use tighter letter-spacing and heavier weights to command attention and convey technological precision. Body text is set with generous line heights to ensure a relaxed reading experience, echoing the brand's promise of a "stress-free" service. All labels are uppercase or medium-weight to ensure they stand out clearly against soft background elements.

## Layout & Spacing
The layout follows a **Fluid Grid** model based on a 12-column system. The philosophy is "Breathable Density": content modules are grouped logically with tight internal spacing (8px-16px), but the modules themselves are separated by significant vertical "breathing room" (80px on desktop) to maintain a feeling of cleanliness.

- **Desktop:** 12 columns, 24px gutters, 64px side margins.
- **Tablet:** 8 columns, 16px gutters, 32px side margins.
- **Mobile:** 4 columns, 16px gutters, 20px side margins.

Horizontal alignment should favor center-weighted layouts for marketing sections and left-aligned, structured grids for functional dashboards.

## Elevation & Depth
Depth is created through **Ambient Shadows** rather than harsh borders. This design system uses "Cloud Shadows"—extremely diffused, large-radius shadows with a slight Indigo tint (#2E3192 at 4-8% opacity).

Surface layers are defined by tonal shifts:
1. **Floor:** The base background in Cool White.
2. **Plinth:** Cards and containers in pure #FFFFFF, raised by a soft shadow.
3. **Float:** Navigation bars and tooltips using a subtle backdrop blur (12px) and 90% opacity to simulate the transparency of water.

## Shapes
The shape language is defined by **Rounded (Level 2)** geometry. This specifically translates to 1rem (16px) for standard components and 1.5rem (24px) for large containers and cards, aligning with the "2xl" aesthetic. 

These generous radii soften the technical nature of the AI service, making the interface feel more approachable and "organic," like the tumbled edges of a smooth stone or the soft folds of fabric. Interactive elements like buttons may occasionally use pill-shapes to further emphasize a friendly, touch-ready experience.

## Components
- **Buttons:** Primary buttons use a Deep Indigo background with white text; secondary buttons use a Soft Lavender tint with Indigo text. All buttons have a minimum height of 48px to remain accessible.
- **Cards:** White backgrounds, 24px corner radius, and a "Cloud Shadow." No borders are used unless the card is placed on a pure white background, in which case a 1px border of #EDF2F7 is applied.
- **Input Fields:** Soft grey-blue backgrounds (#F1F5F9) with a 12px radius. On focus, the border transitions to Sky Blue with a subtle outer glow.
- **Chips/Badges:** Small, pill-shaped elements with low-opacity Mint Green or Sky Blue backgrounds to indicate status (e.g., "Freshly Folded," "In Transit").
- **Icons:** Thin-line (1.5pt to 2pt stroke) icons are mandatory. They should have rounded ends and joints to match the overall shape language of the UI.
- **Progress Indicators:** Use fluid, wave-like animations for loading states to reinforce the laundry/water theme.